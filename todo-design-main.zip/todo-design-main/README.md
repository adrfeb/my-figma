# todo-design
desain aplikasi todo list dengan figma

https://www.figma.com/file/E5MZdxFLMiQiI7pXLnrLFX/Todo-list-app?type=design&node-id=0%3A1&mode=design&t=ZkGZhIXUegmn9Ts1-1
